if (process.env.NODE_ENV !== "production") {
    require('dotenv').config()
  }
  
  const express = require("express");
  const app = express();
  const bcrypt = require("bcrypt")
  const passport = require("passport")
  const flash = require('express-flash')
  const session = require('express-session')
  const mongoose = require("mongoose")
  const users = []
  const initializePassport = require('./passport-config')
  initializePassport(
    passport
  )
  const connectDB = async () => {
    try {
      const con = await mongoose.connect(
        "mongodb+srv://Summaries_Vipara123:Pxgamer22@cluster0.i4eya.mongodb.net/test"
      );
      console.log(`MongoDB connected: ${con.connection.host}`);
    } catch (err) {
      console.log(err);
      process.exit(1);
    }
  };
  connectDB();
  
  const User = require("./models/users");


  app.get('/test', async (req,res)=>{
    const user = await User.findOne({})
    res.send({message:user.name})
  })

  // middleware
  app.set('view-engine','ejs')
  app.use(express.urlencoded({extended:false}))
  app.use(express.static(__dirname + '/public'));
  app.use(flash())
  app.use(session({
    secret: process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: false
  }))
  app.use(passport.initialize())
  app.use(passport.session())
  //

  //Router
  app.get('/',(req,res) => {
    res.render('index.ejs')
  })
  
  app.get('/login',(req,res) => {
    res.render('login.ejs')
  })
  
  app.post('/login', passport.authenticate('local', {
    successRedirect: '/main',
    failureRedirect: '/login',
    failureFlash: true
  }))
  
  app.get('/register',(req,res) => {
    res.render('register.ejs')
    
  })
  
  app.post('/register',async (req,res) => {
    try {
      // setup our admin user
      const hashedPassword = await bcrypt.hash(req.body.password, 10)
      users.push({
        id: Date.now().toString(),
        name: req.body.name,
        email: req.body.email,
        password: hashedPassword
      })
      const data = new User({
        id: Date.now().toString(),
        username:req.body.name,
        email:req.body.email,
        password:hashedPassword})
      data.save();
      res.redirect('/login')
    } catch {
      res.redirect('/register')
    }
    //console.log(users)
  })
  app.get('/profileuser', (req, res) => {
    res.render('userprofile.ejs')
  })

  app.post(
    "profileuser",
    async (req, res) => {
      if (await bcrypt.compare(req.body.editProfilePassword, req.user.password)) {
        try {
          console.log("connect!!!!");
          editProfileProcess.editUserDetails(req, res);
        } catch (e) {
          console.log(e);
        }
      } else {
        res.redirect("login.ejs");
      }
    }
  )

  app.get('/main', (req,res) => {
    console.log(req.user)
    res.render('main.ejs')
  })

  app.listen(3000, function () {
    console.log(
      "Express server listening on port %d  http://localhost:3000/",
      this.address().port
    );
  });

  